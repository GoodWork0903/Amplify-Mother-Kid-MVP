import json
import os
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

COGNITO_USER_POOL_ID = os.environ.get("COGNITO_USER_POOL_ID")
cognito = boto3.client("cognito-idp")

def _response(status, body=None):
    return {
        "statusCode": status,
        "headers": {"content-type": "application/json"},
        "body": json.dumps(body or {})
    }

def _claims(event):
    return event.get("requestContext", {}).get("authorizer", {}).get("jwt", {}).get("claims", {})

# --- GET /v1/tenant-current ---
def tenant_current_handler(event, context):
    claims = _claims(event)
    groups = claims.get("cognito:groups", "")
    tenant_from_claim = claims.get("custom:tenantId")

    is_super_admin = "super_admin" in groups if isinstance(groups, str) else ("super_admin" in (groups or []))

    if not is_super_admin:
        if not tenant_from_claim:
            return _response(403, {"message": "No tenant bound"})
    return _response(200, {
        "tenantId": tenant_from_claim or "super-admin",
        "role": "super_admin" if is_super_admin else "member"
    })

# --- POST /v1/tenant-claim ---
def tenant_claim_handler(event, context):
    claims = _claims(event)
    username = claims.get("sub")
    if not username:
        return _response(401, {"message": "Unauthorized"})

    body = json.loads(event.get("body") or "{}")
    tenant = body.get("tenant")
    if not tenant:
        return _response(400, {"message": "Missing tenant"})

    # check existing
    user = cognito.admin_get_user(UserPoolId=COGNITO_USER_POOL_ID, Username=username)
    attrs = {a["Name"]: a["Value"] for a in user.get("UserAttributes", [])}
    current_tenant = attrs.get("custom:tenantId")

    if current_tenant:
        if current_tenant == tenant:
            return _response(200, {"tenantId": tenant, "status": "already-attached"})
        return _response(409, {"message": "Already bound to another tenant"})

    # attach
    cognito.admin_update_user_attributes(
        UserPoolId=COGNITO_USER_POOL_ID,
        Username=username,
        UserAttributes=[{"Name": "custom:tenantId", "Value": tenant}]
    )
    cognito.admin_add_user_to_group(
        UserPoolId=COGNITO_USER_POOL_ID,
        Username=username,
        GroupName="member"
    )
    return _response(201, {"tenantId": tenant, "status": "attached"})
